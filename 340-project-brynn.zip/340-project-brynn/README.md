# 340-project
Portfolio Group Project with Node 

Citations:

Dr. Curry and Prof. Safonte (August 2023) Citing source code (Version 16.13.0) [Source code] https://github.com/osu-cs340-ecampus/nodejs-starter-app/blob/main/README.md

mdn web docs (August 2023) Citing date display functions (Version 16.13.0) [Date Display Code] https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toLocaleDateString
